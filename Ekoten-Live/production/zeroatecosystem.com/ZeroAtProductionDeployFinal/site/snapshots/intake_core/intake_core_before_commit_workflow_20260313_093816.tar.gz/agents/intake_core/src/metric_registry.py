from __future__ import annotations

from typing import Set
import psycopg


def load_registered_metrics(db_url: str) -> Set[str]:
    sql = """
    select metric_type
    from public.metric_definitions
    """
    with psycopg.connect(db_url) as conn:
        with conn.cursor() as cur:
            cur.execute(sql)
            rows = cur.fetchall()
    return {str(r[0]).strip() for r in rows if r and r[0]}
