from __future__ import annotations

import csv
import io
from dataclasses import dataclass, field
from datetime import datetime, timezone
from decimal import Decimal, InvalidOperation
from typing import Any, Dict, Iterable, List, Optional, Tuple

from agents.intake_core.src.canonical_event import CanonicalEvent
from agents.intake_core.src.fingerprint import build_fingerprint
from agents.intake_core.src.intake_writer import IntakeWriter
from agents.intake_core.src.metric_registry import MetricRegistry
from agents.intake_core.src.facility_registry import FacilityRegistry

# CSV WIDE ROW metrics supported today
ALLOWED_METRICS = {
    "water_m3",
    "energy_kwh",
    "natural_gas_m3",
    "steam_ton",
    "co2_kg",
    "wastewater_m3",
    "production_kg",
    "cod_mg_l",
    "bod_mg_l",
    "tss_mg_l",
    "ph",
}

ZERO_FILL_ALLOWED = {
    "water_m3",
    "energy_kwh",
    "natural_gas_m3",
    "steam_ton",
    "co2_kg",
    "wastewater_m3",
    "production_kg",
    "cod_mg_l",
    "bod_mg_l",
    "tss_mg_l",
}

ZERO_FILL_FORBIDDEN = {
    "facility",
    "event_timestamp",
    "ph",
}

OPTIONAL_META_FIELDS = {
    "process_line",
    "batch_id",
    "order_id",
    "asset_id",
}

DEFAULT_SCHEMA_VERSION = "1.0"
DEFAULT_SOURCE_TYPE = "csv"
DEFAULT_CONFIDENCE_SCORE = 1.0
DEFAULT_TRUST_LEVEL = "high"


@dataclass
class CommitWarning:
    row_index: int
    field: str
    code: str
    message: str


@dataclass
class CommitReject:
    row_index: int
    field: str
    code: str
    message: str


@dataclass
class CommitResult:
    inserted: int = 0
    duplicate: int = 0
    rejected: int = 0
    zero_filled_fields: List[Dict[str, Any]] = field(default_factory=list)
    warnings: List[Dict[str, Any]] = field(default_factory=list)
    rejected_rows: List[Dict[str, Any]] = field(default_factory=list)
    total_input_rows: int = 0
    total_expanded_events: int = 0


class CommitService:
    def __init__(
        self,
        intake_writer: IntakeWriter,
        metric_registry: MetricRegistry,
        facility_registry: FacilityRegistry,
    ) -> None:
        self.intake_writer = intake_writer
        self.metric_registry = metric_registry
        self.facility_registry = facility_registry

    def commit_csv_bytes(
        self,
        file_bytes: bytes,
        file_name: str,
        zero_fill_missing: bool = False,
    ) -> CommitResult:
        text = file_bytes.decode("utf-8-sig", errors="replace")
        reader = csv.DictReader(io.StringIO(text))

        rows = list(reader)
        result = CommitResult(total_input_rows=len(rows))
        all_events: List[CanonicalEvent] = []

        for row_index, raw_row in enumerate(rows, start=1):
            normalized_row = self._normalize_row_keys(raw_row)

            try:
                row_events, row_zero_fills, row_warnings = self._expand_row_to_events(
                    row=normalized_row,
                    row_index=row_index,
                    file_name=file_name,
                    zero_fill_missing=zero_fill_missing,
                )
                all_events.extend(row_events)
                result.zero_filled_fields.extend(row_zero_fills)
                result.warnings.extend(row_warnings)
            except RowRejected as exc:
                result.rejected += 1
                result.rejected_rows.append(
                    {
                        "row_index": row_index,
                        "field": exc.field,
                        "code": exc.code,
                        "message": exc.message,
                    }
                )

        result.total_expanded_events = len(all_events)

        if all_events:
            write_result = self.intake_writer.write_many(all_events)

            result.inserted = int(write_result.get("inserted", 0))
            result.duplicate = int(write_result.get("duplicate", 0))
            # keep hard row rejects + writer rejects
            result.rejected += int(write_result.get("rejected", 0))

            writer_warnings = write_result.get("warnings", [])
            if writer_warnings:
                result.warnings.extend(writer_warnings)

        return result

    def _expand_row_to_events(
        self,
        row: Dict[str, Any],
        row_index: int,
        file_name: str,
        zero_fill_missing: bool,
    ) -> Tuple[List[CanonicalEvent], List[Dict[str, Any]], List[Dict[str, Any]]]:
        zero_filled_fields: List[Dict[str, Any]] = []
        warnings: List[Dict[str, Any]] = []

        facility_raw = self._clean_str(row.get("facility"))
        if not facility_raw:
            raise RowRejected("facility", "missing_required", "facility is required")

        facility_id = self._resolve_facility_id(facility_raw)

        event_timestamp = self._resolve_event_timestamp(row.get("event_timestamp"))
        if event_timestamp is None:
            raise RowRejected(
                "event_timestamp",
                "missing_required",
                "event_timestamp is required or must be derivable",
            )

        process_line = self._clean_str(row.get("process_line"))
        batch_id = self._clean_str(row.get("batch_id"))
        order_id = self._clean_str(row.get("order_id"))
        asset_id = self._clean_str(row.get("asset_id"))

        source_event_id = self._build_source_event_id(file_name=file_name, row_index=row_index)

        events: List[CanonicalEvent] = []

        for metric_type in ALLOWED_METRICS:
            raw_value = row.get(metric_type)

            if self._is_blank(raw_value):
                if metric_type in ZERO_FILL_ALLOWED and zero_fill_missing:
                    value = Decimal("0")
                    zero_filled_fields.append(
                        {
                            "row_index": row_index,
                            "field": metric_type,
                            "value": "0",
                        }
                    )
                    warnings.append(
                        {
                            "row_index": row_index,
                            "field": metric_type,
                            "code": "zero_filled",
                            "message": f"{metric_type} was missing and filled with 0",
                        }
                    )
                else:
                    continue
            else:
                value = self._to_decimal(raw_value, metric_type)

            if metric_type == "ph" and value == 0:
                raise RowRejected(
                    "ph",
                    "invalid_zero_value",
                    "ph cannot be zero-filled or committed as 0",
                )

            metric_def = self.metric_registry.get_metric_definition(metric_type)
            if not metric_def:
                raise RowRejected(
                    metric_type,
                    "metric_not_registered",
                    f"metric {metric_type} not registered in metric_definitions",
                )

            unit = metric_def["canonical_unit"]

            source_metadata = {
                "file_name": file_name,
                "row_index": row_index,
                "source_format": "wide_row_csv",
                "original_facility": facility_raw,
            }

            fingerprint = build_fingerprint(
                facility_id=facility_id,
                source_type=DEFAULT_SOURCE_TYPE,
                metric_type=metric_type,
                value=str(value),
                unit=unit,
                event_timestamp=event_timestamp.isoformat(),
                process_line=process_line,
                batch_id=batch_id,
                order_id=order_id,
                asset_id=asset_id,
                source_event_id=source_event_id,
            )

            event = CanonicalEvent(
                facility_id=facility_id,
                source_type=DEFAULT_SOURCE_TYPE,
                metric_type=metric_type,
                value=value,
                unit=unit,
                event_timestamp=event_timestamp,
                process_line=process_line,
                batch_id=batch_id,
                order_id=order_id,
                asset_id=asset_id,
                confidence_score=DEFAULT_CONFIDENCE_SCORE,
                trust_level=DEFAULT_TRUST_LEVEL,
                source_event_id=source_event_id,
                idempotency_key=fingerprint,
                fingerprint=fingerprint,
                source_metadata=source_metadata,
                validation_errors=[],
                event_id=None,
                ingested_at=datetime.now(timezone.utc),
                schema_version=DEFAULT_SCHEMA_VERSION,
            )
            events.append(event)

        if not events:
            raise RowRejected(
                "row",
                "no_metrics_found",
                "row produced zero canonical events",
            )

        return events, zero_filled_fields, warnings

    def _resolve_facility_id(self, facility_raw: str) -> str:
        facility_id = facility_raw.strip().lower()

        facility = self.facility_registry.get_facility(facility_id)
        if facility:
            return facility["facility_id"]

        # allow alias-ish fallback if registry supports search
        facility_by_name = self.facility_registry.find_by_name(facility_raw)
        if facility_by_name:
            return facility_by_name["facility_id"]

        raise RowRejected(
            "facility",
            "facility_not_found",
            f"facility not found in registry: {facility_raw}",
        )

    def _resolve_event_timestamp(self, raw_value: Any) -> Optional[datetime]:
        if self._is_blank(raw_value):
            # deterministic fallback for current CSV stage:
            # use current UTC time only if architecture already allows ingestion-time timestamping
            # if you want strict blocking, replace next line with: return None
            return datetime.now(timezone.utc)

        text = str(raw_value).strip()

        # accept ISO-ish formats
        try:
            dt = datetime.fromisoformat(text.replace("Z", "+00:00"))
            if dt.tzinfo is None:
                return dt.replace(tzinfo=timezone.utc)
            return dt.astimezone(timezone.utc)
        except Exception:
            raise RowRejected(
                "event_timestamp",
                "invalid_timestamp",
                f"invalid event_timestamp: {text}",
            )

    def _build_source_event_id(self, file_name: str, row_index: int) -> str:
        return f"{file_name}:row:{row_index}"

    def _normalize_row_keys(self, row: Dict[str, Any]) -> Dict[str, Any]:
        normalized: Dict[str, Any] = {}
        for k, v in row.items():
            key = (k or "").strip()
            normalized[key] = v
        return normalized

    def _to_decimal(self, value: Any, field_name: str) -> Decimal:
        text = str(value).strip().replace(",", ".")
        try:
            return Decimal(text)
        except (InvalidOperation, ValueError):
            raise RowRejected(
                field_name,
                "invalid_numeric",
                f"invalid numeric value for {field_name}: {value}",
            )

    def _clean_str(self, value: Any) -> Optional[str]:
        if value is None:
            return None
        text = str(value).strip()
        return text or None

    def _is_blank(self, value: Any) -> bool:
        return value is None or str(value).strip() == ""


class RowRejected(Exception):
    def __init__(self, field: str, code: str, message: str) -> None:
        super().__init__(message)
        self.field = field
        self.code = code
        self.message = message
